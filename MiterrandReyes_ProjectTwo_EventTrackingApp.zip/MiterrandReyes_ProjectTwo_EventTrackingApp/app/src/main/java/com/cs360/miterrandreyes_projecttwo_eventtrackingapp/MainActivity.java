package com.cs360.miterrandreyes_projecttwo_eventtrackingapp;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    //Username edit text field
    private EditText editTextText;
    //password edit text field
    private EditText editTextTextPassword;
    //login button
    private Button button;
    //new user button
    private Button button2;
    private MyDatabaseHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Initialize
        editTextText = findViewById(R.id.editTextText);
        editTextTextPassword = findViewById((R.id.editTextTextPassword));
        button = findViewById(R.id.button);
        button2 = findViewById(R.id.button2);

        // Initialize database for user login info
        db = new MyDatabaseHelper(MainActivity.this);

    }

    // ***** login method with verification logic ****
    //
    // set this method to the onClick attribute of button which is the login button.
    public void login (View view) {
        String usernameInput = editTextText.getText().toString().trim();
        String passwordInput = editTextTextPassword.getText().toString().trim();

        /*
         * *** Following two IF statements are critical for correct login function ***
         */
        // Check if both username and passwords fields are empty
        // if empty and login button is clicked display message
        // stops immediately if username and passwords fields are empty.
        if(usernameInput.isEmpty() || passwordInput.isEmpty()) {
            Toast.makeText(this, "Please enter username and password", Toast.LENGTH_SHORT).show();
            return;
        }

        // checks if username exists in login attempt
        // stops immediately if username does not exist
        if(!db.userExists(usernameInput)) {
            Toast.makeText(this, "User does not exist", Toast.LENGTH_SHORT).show();
            return;
        }

        // Finally once fields are NOT empty and username EXISTS attempt login ONLY if password is correct
        if(db.userExists(usernameInput)) {
            if(db.checkUser(usernameInput, passwordInput)) {
                // login is successful message
                Toast.makeText(this, "Login Successful", Toast.LENGTH_SHORT).show();
                // allows user to enter application
                Intent intent = new Intent(MainActivity.this, DataDisplayGridActivity.class);
                startActivity(intent);
            }else{
                // password is incorrect message
                Toast.makeText(this, "Incorrect password", Toast.LENGTH_SHORT).show();
            }
        }
    }

    // ***** newUser method with verification logic ****
    //
    // set this method to the onClick attribute of New User button and simulated Toast messages which
    // let user know what to do when creating a new account
    public void newUser (View view) {
        String usernameInput = editTextText.getText().toString().trim();
        String passwordInput = editTextTextPassword.getText().toString().trim();

        /*
         * *** Following two IF statements are critical for correct new user creation function ***
         */
        // Check if both username and passwords fields are empty
        // if empty and login button is clicked display message
        // stops logic immediately if fields are empty
        if(usernameInput.isEmpty() || passwordInput.isEmpty()) {
            Toast.makeText(this, "Please enter username and password", Toast.LENGTH_SHORT).show();
            return;
        }

        // checks if username is already taken (exists in db)
        // stops logic immediately if user is already taken
        if(db.userExists(usernameInput)) {
            Toast.makeText(this, "Username is already taken", Toast.LENGTH_SHORT).show();
            return;
        }

        // Finally if username is unique and password is entered allow user creation
        // if username is new create account
        boolean created = db.insertUsers(usernameInput, passwordInput);

        if(created) {
            Toast.makeText(this, "Account Created", Toast.LENGTH_SHORT).show();
            // allows user to enter application
            Intent intent = new Intent(MainActivity.this, DataDisplayGridActivity.class);
            startActivity(intent);
        }else{
            Toast.makeText(this, "Failed to create account", Toast.LENGTH_SHORT).show();
        }
    }

    // Quality of life helper
    // used throughout the code wherever a user pops up a keyboard. Keyboard will dispatch
    // if used touches outside text field
    @Override
    public boolean dispatchTouchEvent(MotionEvent event) {
        if (getCurrentFocus() != null) {
            InputMethodManager inputMethodManager = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            inputMethodManager.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(), 0);
        }
        return super.dispatchTouchEvent(event);
    }

}