package com.cs360.miterrandreyes_projecttwo_eventtrackingapp;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.service.autofill.CustomDescription;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class CustomAdapter extends RecyclerView.Adapter<CustomAdapter.MyViewHolder> {

    private Context context;
    Activity activity;
    private ArrayList event_id, event_title, event_date, event_time, event_details;

    CustomAdapter(Activity activity, Context context,
                  ArrayList event_id,
                  ArrayList event_title,
                  ArrayList event_date,
                  ArrayList event_time,
                  ArrayList event_details) {
        this.activity = activity;
        this.context = context;
        this.event_id = event_id;
        this.event_title = event_title;
        this.event_date = event_date;
        this.event_time = event_time;
        this.event_details = event_details;
    }

    @NonNull
    @Override
    public CustomAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.my_row, parent, false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull CustomAdapter.MyViewHolder holder, final int position) {

        /*
         * Create holder
         * Data is bound to every text field of the RecyclerView
         */
        holder.event_id_text.setText(String.valueOf(event_id.get(position)));
        holder.event_title_text.setText(String.valueOf(event_title.get(position)));
        holder.event_date_text.setText(String.valueOf(event_date.get(position)));
        holder.event_time_text.setText(String.valueOf(event_time.get(position)));
        holder.event_details_text.setText(String.valueOf(event_details.get(position)));

        /*
         * Update holder
         * Each row is its own main layout
         * When a user taps a row UpdateActivity runs
         * pulling the current data of the row and displaying it for editing
         */
        holder.mainLayout.setOnClickListener((view) -> {
            Intent intent = new Intent(context, UpdateActivity.class);
            intent.putExtra("id", String.valueOf(event_id.get(position)));
            intent.putExtra("title", String.valueOf(event_title.get(position)));
            intent.putExtra("date", String.valueOf(event_date.get(position)));
            intent.putExtra("time", String.valueOf(event_time.get(position)));
            intent.putExtra("details", String.valueOf(event_details.get(position)));
            activity.startActivityForResult(intent, 1);
        });

        /*
         * Delete holder
         * Each row contains a delete button instance.
         * Listens for when the delete button is tapped
         * Displays a confirmation dialog
         * If deletion is desired deletes row
         */
        holder.delete_event_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                // gets latest adapter position
                int position = holder.getAbsoluteAdapterPosition();
                if (position == RecyclerView.NO_POSITION) return;

                String idToDelete = event_id.get(position).toString();
                String titleToShow = event_title.get(position).toString();

                /*
                 * Delete alert dialog
                 * Pops up to confirm deletion of row
                 * Prevents accidental deletion and displays confirmation text once deleted.
                 */
                AlertDialog.Builder builder = new AlertDialog.Builder(context);

                builder.setTitle("Delete Event");
                builder.setMessage("Are you sure you want to delete event? \n\n" + "Event: " + titleToShow);

                /*
                 * If yes is selected calls deleteOneRow method and deletes row
                 */
                builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        MyDatabaseHelper myDB = new MyDatabaseHelper(context);
                        myDB.deleteOneRow(idToDelete);

                        event_id.remove(position);
                        event_title.remove(position);
                        event_date.remove(position);
                        event_time.remove(position);
                        event_details.remove(position);

                        notifyItemRemoved(position);
                        notifyItemRangeChanged(position, event_id.size());
                    }
                });
                /*
                 * If no option is selected dismiss the popup and do nothing
                 */
                builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
                /*
                 * Shows the confirmation dialog box
                 */
                builder.create().show();
            }
        });
    }

    @Override
    public int getItemCount() {
        return event_id.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView event_id_text, event_title_text, event_date_text, event_time_text, event_details_text;
        ConstraintLayout mainLayout;
        Button delete_event_button;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            event_id_text = itemView.findViewById(R.id.event_id_text);
            event_title_text = itemView.findViewById(R.id.event_title_text);
            event_date_text = itemView.findViewById(R.id.event_date_text);
            event_time_text = itemView.findViewById(R.id.event_time_text);
            event_details_text = itemView.findViewById(R.id.event_details_text);
            mainLayout = itemView.findViewById(R.id.mainLayout);

            //delete button
            delete_event_button = itemView.findViewById(R.id.delete_event_button);
        }
    }
}
