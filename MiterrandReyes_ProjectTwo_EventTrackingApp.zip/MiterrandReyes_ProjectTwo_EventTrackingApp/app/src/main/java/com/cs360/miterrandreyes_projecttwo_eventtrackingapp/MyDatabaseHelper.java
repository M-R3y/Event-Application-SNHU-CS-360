package com.cs360.miterrandreyes_projecttwo_eventtrackingapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

import androidx.annotation.Nullable;

public class MyDatabaseHelper extends SQLiteOpenHelper {

    private final Context context;
    // Event.db Database
    private static final String DATABASE_NAME = "Event.db";
    private static final int DATABASE_VERSION = 2;

    // USERS TABLE CONSTANTS
    private static final String USERS_TABLE = "users";
    private static final String COLUMN_USER_ID = "user_id";
    private static final String COLUMN_USERNAME = "username";
    private static final String COLUMN_PASSWORD = "password";

    // EVENT TABLE CONSTANTS
    private static final String TABLE_NAME = "my_events";
    //columns
    private static final String COLUMN_ID = "_id";
    private static final String COLUMN_TITLE = "event_title";
    private static final String COLUMN_DATE = "event_date";
    private static final String COLUMN_TIME = "event_time";
    private static final String COLUMN_DETAILS = "event_details";

    MyDatabaseHelper(@Nullable Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
        this.context = context;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        // EVENTS TABLE
        String query = "CREATE TABLE " + TABLE_NAME +
                " (" + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_TITLE + " TEXT, " +
                COLUMN_DATE + " TEXT, " +
                COLUMN_TIME + " TEXT, " +
                COLUMN_DETAILS + " TEXT);";

        // USERS TABLE
        String userQuery = "CREATE TABLE " + USERS_TABLE +
                " (" +COLUMN_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_USERNAME + " TEXT UNIQUE, " +
                COLUMN_PASSWORD + " TEXT); ";

        // Creates both tables in Event.db
        db.execSQL(query);
        db.execSQL(userQuery);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        db.execSQL("DROP TABLE IF EXISTS " + USERS_TABLE);
        onCreate(db);
    }

    // ****** CRUD Implementation for EVENT TABLE (TABLE_TABLE) ******

    // CREATE
    void addEvent(String title, String date, String time, String details) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();

        cv.put (COLUMN_TITLE, title);
        cv.put (COLUMN_DATE, date);
        cv.put (COLUMN_TIME, time);
        cv.put (COLUMN_DETAILS, details);
        long result = db.insert(TABLE_NAME, null, cv);
        // if data is added to table show success message
        if(result == -1) {
            Toast.makeText(context, "Failed", Toast.LENGTH_SHORT).show();
        }else {
            Toast.makeText(context, "Added Successfully!", Toast.LENGTH_SHORT).show();
        }
    }

    // READ
    Cursor readAllData(){
        String query = "SELECT * FROM " + TABLE_NAME;
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = null;
        if(db != null) {
            cursor = db.rawQuery(query, null);
        }
        return cursor;
    }

    // UPDATE
    void updateData(String row_id, String title, String date, String time, String details) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(COLUMN_TITLE, title);
        cv.put(COLUMN_DATE, date);
        cv.put(COLUMN_TIME, time);
        cv.put(COLUMN_DETAILS, details);

        long result = db.update(TABLE_NAME, cv, "_id=?", new String[]{row_id});
        if(result == -1) {
            Toast.makeText(context, "Failed to Update", Toast.LENGTH_SHORT).show();
        }else{
            Toast.makeText(context, "Successfully Update!", Toast.LENGTH_SHORT).show();
        }
    }

    // DELETE
    void deleteOneRow(String row_id) {
        SQLiteDatabase db = this.getWritableDatabase();
        long result = db.delete(TABLE_NAME, "_id=?", new String[]{row_id});
        if(result == -1) {
            Toast.makeText(context,"Failed to delete", Toast.LENGTH_SHORT).show();
        }else{
            Toast.makeText(context,"Successfully Deleted", Toast.LENGTH_SHORT).show();
        }
    }

    void deleteAllData() {
        SQLiteDatabase db = this.getWritableDatabase();
        db.execSQL("DELETE FROM " + TABLE_NAME);
    }

    // ****** LOGIN METHOD Implementation for USERS TABLE (USERS_TABLE) ******
    // boolean methods are used for this critical part of the application which requires decision-making
    // end goal is to determine whether a username exists, credentials match, or a new user was created
    // MainActivity handles the user messages which will indicate whether these goals were met or need attention

    // insertUsers attempts to insert a new user into the USERS_TABLE
    public boolean insertUsers(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();

        cv.put(COLUMN_USERNAME, username);
        cv.put(COLUMN_PASSWORD, password);

        long result = db.insert(USERS_TABLE, null, cv);
        // true = success successful username addition
        // false = fail username already exists
        return result != -1;
    }

    // userExists whether a username already exists in the db
    public boolean userExists(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(
                "SELECT * FROM " + USERS_TABLE + " WHERE " + COLUMN_USERNAME + "= ?",
                new String[]{username}
        );
        boolean exists = cursor.getCount() > 0;
        cursor.close();
        // true = username exists
        // false = username doesn't exist
        return exists;
    }

    // checkUser validates a password/username combination
    public boolean checkUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(
                "SELECT * FROM " + USERS_TABLE + " WHERE " + COLUMN_USERNAME + " = ? AND " + COLUMN_PASSWORD + " = ?",
                new String []{username, password}
        );
        boolean valid = cursor.getCount() > 0;
        cursor.close();
        // true = matching credentials
        // false = no matching credentials
        return valid;
    }
}
