package com.cs360.miterrandreyes_projecttwo_eventtrackingapp;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.view.MotionEvent;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.material.appbar.MaterialToolbar;

public class UpdateActivity extends AppCompatActivity {
    MaterialToolbar topAddEventActivityBa2;
    EditText title_input, date_input, time_input, details_input;
    Button update_button;
    // variables which will hold the event data passed from the home screen
    String id, title, date, time, details;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_update);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // initialize
        MaterialToolbar toolbar = findViewById(R.id.topAddEventActivityBar2);
        setSupportActionBar(toolbar);
        title_input = findViewById(R.id.event_title_name_input2);
        date_input = findViewById(R.id.event_date_input2);
        time_input = findViewById(R.id.event_time_input2);
        details_input = findViewById(R.id.event_details_input2);
        update_button = findViewById(R.id.update_event_button);

        // *** Toolbar Navigation ***
        // Navigation for project two UI presentation
        // Handles back arrow click in AddEventActivity toolbar to return to DataDisplayGridActivity
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(UpdateActivity.this, DataDisplayGridActivity.class);
                startActivity(intent);
                finish();
            }
        });

        // First we call this getAndSetIntentData() will load event data passed from the CustomAdapter
        // and populate the fields in the UpdateActivity.
        getAndSetIntentData();

        // Update Button logic
        // Will get the new text field data and call updateData to save editied fields
        update_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MyDatabaseHelper myDB = new MyDatabaseHelper(UpdateActivity.this);

                // Read new values from update_main EditTexts
                title = title_input.getText().toString().trim();
                date = date_input.getText().toString().trim();
                time = time_input.getText().toString().trim();
                details = details_input.getText().toString().trim();

                // And only then we call updateData in order to update event data
                myDB.updateData(id, title, date, time, details);

                // After update navigate back to the homescreen
                Intent intent = new Intent(UpdateActivity.this, DataDisplayGridActivity.class);
                startActivity(intent);
                finish();
            }
        });
    }
    /*
     *  getAndSetIntentData() method
     *  Retrieves event data from the row and passes it to the Update Activity Screen alongside the events title.
     */
    void getAndSetIntentData() {
        if(getIntent().hasExtra("id") &&
                getIntent().hasExtra("title") &&
                getIntent().hasExtra("date") &&
                getIntent().hasExtra("time") &&
                getIntent().hasExtra("details")) {

            // Getting Data from intent
            id = getIntent().getStringExtra("id");
            title = getIntent().getStringExtra("title");
            date = getIntent().getStringExtra("date");
            time = getIntent().getStringExtra("time");
            details = getIntent().getStringExtra("details");

            // setting Intent Data
            title_input.setText(title);
            date_input.setText(date);
            time_input.setText(time);
            details_input.setText(details);

            // dynamically change the title of the toolbar to let user know which event is clicked
            MaterialToolbar toolbar = findViewById(R.id.topAddEventActivityBar2);
            toolbar.setTitle(title);

        }else{
            Toast.makeText(this, "No data", Toast.LENGTH_SHORT).show();
        }
    }

    // Quality of life helper
    // due to the event detail having the possibility to cause a sticking problem for the user
    // sticking problem meaning that since the event details field accepts multiple lines of text originally
    // the enter key was present in the keyboard and if the user continued to press it an additional line would appear
    // this method closes the keyboard whenever the user clicks out of any text input fields
    @Override
    public boolean dispatchTouchEvent(MotionEvent event) {
        if (getCurrentFocus() != null) {
            InputMethodManager inputMethodManager = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            inputMethodManager.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(), 0);
        }
        return super.dispatchTouchEvent(event);
    }

}