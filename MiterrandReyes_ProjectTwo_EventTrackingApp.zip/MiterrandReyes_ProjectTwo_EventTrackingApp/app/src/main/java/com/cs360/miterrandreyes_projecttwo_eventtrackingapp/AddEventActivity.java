package com.cs360.miterrandreyes_projecttwo_eventtrackingapp;

import android.Manifest;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TimePicker;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import com.google.android.material.appbar.MaterialToolbar;

import java.util.Calendar;

public class AddEventActivity extends AppCompatActivity {

    private static final int SMS_PERMISSION_REQUEST_CODE = 100;
    MaterialToolbar topAddEventActivityBar;
    EditText event_title_name_input, event_date_input, event_time_input, event_details_input;
    Button add_event_button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_add_event);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // initialize
        MaterialToolbar toolbar = findViewById(R.id.topAddEventActivityBar);
        setSupportActionBar(toolbar);
        // *** Toolbar Navigation ***
        // Navigation for project two UI presentation
        // Handles back arrow click in AddEventActivity toolbar to return to DataDisplayGridActivity
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(AddEventActivity.this, DataDisplayGridActivity.class);
                startActivity(intent);
                finish();
            }
        });
        event_title_name_input = findViewById(R.id.event_title_name_input);
        event_details_input = findViewById(R.id.event_details_input);
        add_event_button = findViewById(R.id.add_event_button);

        // date picker initialize
        event_date_input = findViewById(R.id.event_date_input);
        // makes the field behave like a button instead of a text box no keyboard appears only date picker
        event_date_input.setFocusable(false);
        event_date_input.setClickable(true);

        // time picker initialize
        event_time_input = findViewById(R.id.event_time_input);
        // makes the field behave like a button instead of a text box no keyboard appears only time picker
        event_time_input.setFocusable(false);
        event_time_input.setClickable(true);

        // *** Add event button ***
        // when button is tapped gets text from all text fields
        add_event_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String title = event_title_name_input.getText().toString().trim();
                String date = event_date_input.getText().toString().trim();
                String time = event_time_input.getText().toString().trim();
               // String details = event_details_input.getText().toString().trim();

                // validate title, date, and time fields are not empty
                if (title.isEmpty() || date.isEmpty() || time.isEmpty()) {
                    Toast.makeText(AddEventActivity.this, "Please include title, date, time", Toast.LENGTH_SHORT).show();
                    return;
                }

                // if basic event info is filled in add event to db
                MyDatabaseHelper myDB = new MyDatabaseHelper(AddEventActivity.this);
                myDB.addEvent(event_title_name_input.getText().toString().trim(),
                            event_date_input.getText().toString().trim(),
                            event_time_input.getText().toString().trim(),
                            event_details_input.getText().toString().trim());

                // calls method for SMS notification functionality
                showSmsNotificationDialog();
            }
        });

        // *** DatePicker ***
        // Displays a interactive calendar
        // Reference: https://www.geeksforgeeks.org/android/datepicker-in-android/
        event_date_input.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // gets today's date
                final Calendar calendar = Calendar.getInstance();
                // initializes DatePicker with the current date
                int year = calendar.get(Calendar.YEAR);
                int month = calendar.get(Calendar.MONTH);
                int day = calendar.get(Calendar.DAY_OF_MONTH);

                DatePickerDialog datePicker = new DatePickerDialog(AddEventActivity.this,
                        new DatePickerDialog.OnDateSetListener() {
                            @Override
                            public void onDateSet(DatePicker datePicker, int selectedYear, int selectedMonth, int selectedDay) {
                                String date = (selectedMonth + 1) + "/" + selectedDay + "/" + selectedYear;
                                event_date_input.setText(date);
                            }
                        },
                        year, month, day
                );
                datePicker.show();
            }
        });

        // *** TimePicker ***
        // Displays a selection wheel style time picker
        // Reference: https://www.geeksforgeeks.org/android/timepicker-in-android/
        event_time_input.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                final Calendar calendar = Calendar.getInstance();
                int hour = calendar.get(Calendar.HOUR_OF_DAY);
                int minute = calendar.get(Calendar.MINUTE);

                TimePickerDialog timePicker = new TimePickerDialog(AddEventActivity.this,
                        new TimePickerDialog.OnTimeSetListener() {
                            @Override
                            public void onTimeSet(TimePicker timePicker, int selectedHour, int selectedMinute) {
                                int hour = selectedHour;
                                String amPm;
                                // Determine AM or PM and adjust hour
                                if(hour == 0) {
                                    hour += 12;
                                    amPm = "AM";
                                }else if(hour == 12) {
                                    amPm = "PM";
                                }else if(hour > 12) {
                                    hour -= 12;
                                    amPm = "PM";
                                }else{
                                    amPm = "AM";
                                }

                                // format hour and minute for display
                                String formattedHour = (hour < 10) ? "0" + hour : String.valueOf(hour);
                                String formattedMinute = (selectedMinute < 10) ? "0" + selectedMinute : String.valueOf(selectedMinute);

                                // Displays formatter time
                                String time = formattedHour + ":" + formattedMinute + " " +amPm;
                                event_time_input.setText(time);
                            }
                        },
                        hour, minute,false    // false = 12-hour format, true = 24-hour format
                );
                timePicker.show();
            }
        });
    }

    /*
     ***************** SMS NOTIFICATION METHODS ****************
     */

    // Checks current SEND_SMS permission for the application
    private boolean smsPermissionGranted() {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED;
    }

    // Requests SEND_SMS permission from the user by showing an android system popup
    private void requestSmsPermission () {
        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS},
            SMS_PERMISSION_REQUEST_CODE
        );
    }

    // Method receives the users decision of the android system popup permission request for SEND_SMS
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if(requestCode == SMS_PERMISSION_REQUEST_CODE) {
            if(grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Allow
                showSmsSentDialog();
            }else{
                // Deny
                showSmsDeniedDialog();
            }
        }
    }

    // SMS notification decision which will be made by the user
    // Dialog will ask user if they want an SMS reminder regarding the event
    // if yes SMS permission will be checked
    private void showSmsNotificationDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);

        builder.setTitle("Send SMS Reminder?");
        builder.setMessage("Would you like an SMS reminder for this event?");

        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                if(smsPermissionGranted()) {
                    showSmsSentDialog();
                }else{
                    requestSmsPermission();
                }
            }
        });
        builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                navigateBackToHome();
            }
        });
        builder.create().show();
    }

    // Dialog which shows SMS permission is approved and an SMS alert will be sent
    private void showSmsSentDialog() {
        new AlertDialog.Builder(this)
                .setTitle("SMS Permission Approved")
                .setMessage("An SMS alert will be sent for this event")
                .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        navigateBackToHome();
                    }
                })
                .show();
    }

    // Dialog which shows SMS permission is denied and alerts cant be sent
    private void showSmsDeniedDialog() {
        new AlertDialog.Builder(this)
                .setTitle("SMS Permission Denied")
                .setMessage("SMS alert cannot be send without permission")
                .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        navigateBackToHome();
                    }
                })
                .show();
    }

    // Helper method to navigate back to the home screen
    private void navigateBackToHome() {
        Intent intent = new Intent(AddEventActivity.this, DataDisplayGridActivity.class);
        startActivity(intent);
        finish();
    }

    // Quality of life helper
    // due to the event detail having the possibility to cause a sticking problem for the user
    // sticking problem meaning that since the event details field accepts multiple lines of text originally
    // the enter key was present in the keyboard and if the user continued to press it an additional line would appear
    // this method closes the keyboard whenever the user clicks out of any text input fields
    @Override
    public boolean dispatchTouchEvent(MotionEvent event) {
        if (getCurrentFocus() != null) {
            InputMethodManager inputMethodManager = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            inputMethodManager.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(), 0);
        }
        return super.dispatchTouchEvent(event);
    }
}



