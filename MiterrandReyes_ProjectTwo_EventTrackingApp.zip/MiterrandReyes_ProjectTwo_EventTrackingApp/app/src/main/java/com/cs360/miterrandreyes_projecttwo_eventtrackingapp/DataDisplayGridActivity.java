package com.cs360.miterrandreyes_projecttwo_eventtrackingapp;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

public class DataDisplayGridActivity extends AppCompatActivity {

    TextView no_data;
    MaterialToolbar topDataDisplayGridActivityBar;
    RecyclerView recyclerView;
    FloatingActionButton add_button;
    MyDatabaseHelper myDB;
    ArrayList<String> event_id, event_title, event_date, event_time, event_details;
    CustomAdapter customAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_data_display_grid);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Initialize
        MaterialToolbar toolbar = findViewById(R.id.topDataDisplayGridActivityBar);
        setSupportActionBar(toolbar);
        // no data text view which only displays when no events are stored.
        no_data = findViewById(R.id.no_data);
        // initialize recycler view resource: tutorial video series part 1
        recyclerView = findViewById(R.id.recyclerView);
        add_button = findViewById(R.id.add_button);
        // add button which is located in bottom right corner with a plus sign
        // from the main Event Tracker screen if the bottom right ADD button is pressed
        // navigate to the add event activity screen
        add_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(DataDisplayGridActivity.this, AddEventActivity.class);
                startActivity((intent));
            }
        });

        // initialize array lists
        myDB = new MyDatabaseHelper(DataDisplayGridActivity.this);
        event_id = new ArrayList<>();
        event_title = new ArrayList<>();
        event_date = new ArrayList<>();
        event_time = new ArrayList<>();
        event_details = new ArrayList<>();

        storeDataInArrays();

        customAdapter = new CustomAdapter(DataDisplayGridActivity.this, this, event_id, event_title, event_date, event_time, event_details);
        recyclerView.setAdapter(customAdapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(DataDisplayGridActivity.this));
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == 1) {
            recreate();
        }
    }

    void storeDataInArrays(){
        Cursor cursor = myDB.readAllData();
        if(cursor.getCount() == 0) {
            Toast.makeText(this,"No data",Toast.LENGTH_SHORT).show();
            no_data.setVisibility(View.VISIBLE);
        }else{
            while (cursor.moveToNext()){
                event_id.add(cursor.getString(0));
                event_title.add(cursor.getString(1));
                event_date.add(cursor.getString(2));
                event_time.add(cursor.getString(3));
                event_details.add(cursor.getString(4));
            }
            no_data.setVisibility(View.GONE);
        }
    }

    /*
     * ******** DELETE ALL *********
     * Methods handle the upper right hand trash icon which user can use to
     * Delete all event data in the app home screen
     */
    // inflates the upper right hand menu icon
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.my_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    // if delete_all upper right hand corner trash icon is selected call confirmDialog method
    // for all event deletion final confirmation
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if(item.getItemId()==R.id.delete_all){
            confirmDialog();
        }
        return super.onOptionsItemSelected(item);
    }

    // Upper right hand trash icon method for deleting all event data uses an alert dialog box
    // so user can confirm deletion of ALL events.
    void confirmDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);

        builder.setTitle("Delete All Events?");
        builder.setMessage("Are you sure you want to delete all Event Data");

        // if yes is selected process to delete all the data from db and refresh the activity by
        // reloading the same activity.
        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                MyDatabaseHelper myDB = new MyDatabaseHelper(DataDisplayGridActivity.this);
                myDB.deleteAllData();
                // Refreshes activity
                Intent intent = new Intent(DataDisplayGridActivity.this, DataDisplayGridActivity.class);
                startActivity(intent);
                finish();
            }
        });

        // if no option is selected dismiss the dialog
        builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
        // shows alert dialog box
        builder.create().show();
    }
}

